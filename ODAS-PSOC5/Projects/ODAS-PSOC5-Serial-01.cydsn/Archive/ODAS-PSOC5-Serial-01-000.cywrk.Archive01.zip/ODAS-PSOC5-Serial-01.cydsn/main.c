/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"

void blinkLED(uint8 blinkTime)
{
    LED_Write(1);
    CyDelay(blinkTime);
    LED_Write(0);
}

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

int main(void)
{   
    char8 ch;       /* Data received from the Serial port */

    CyGlobalIntEnable; /* Enable all interrupts by the processor. */

    UART_1_Start();
    blinkLED(250);

    while(1)
    {
        /* Check the UART status */
        ch = UART_1_GetChar();

        /* If byte received */
        if(ch > 0u)
        {
            blinkLED(5);
            Control_Reg_1_Write(ch);         /* Print the received character */
        }
    }
}

/* [] END OF FILE */
