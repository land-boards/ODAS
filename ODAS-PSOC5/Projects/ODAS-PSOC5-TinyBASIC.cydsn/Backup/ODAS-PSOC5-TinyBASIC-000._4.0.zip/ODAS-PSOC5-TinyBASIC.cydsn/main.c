/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"
int mainTinyBASIC(int, char*);
char noPtr[1];

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

int main(void)
{
    
while(1)
mainTinyBASIC(0,noPtr);

}

/* [] END OF FILE */
